#!/usr/bin/env python3
"""
TBOX / IVI dual-modulus OTA challenge generator (offline).

Two ECUs have independent RSA moduli (no shared prime — gcd(n1,n2)==1).
Diagnostics leak masked MSBs of p1; factoring requires recovering the
combiner keystream then Coppersmith. n2 uses a nearby prime only as a
PKI twin (does not share factors with n1).
"""

from __future__ import annotations

import hashlib
import json
import math
import operator
import random
from pathlib import Path

from Crypto.Util.number import getPrime, isPrime, long_to_bytes, bytes_to_long

HERE = Path(__file__).resolve().parent
FIXED_SEED = 0x2EAD2026C072
random.seed(FIXED_SEED)

VIN = "LHGAV3850A2012345"
MOD_BITS = 1024
P_BITS = MOD_BITS // 2
# Tighter leak: unknown = 236 bits (theory ~256 for beta=1/2); needs careful Coppersmith.
KNOWN_P_BITS = 276
SEED_BITS = 32  # full 32-bit combiner seed
DELTA_BITS = 96  # p2 = p1 + delta (nearby twin); q2 independent


def md5_hex(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(operator.xor(x, y) for x, y in zip(a, b))


class CombGenerator:
    """Two Galois LFSRs combined with OR — not linearly recoverable."""

    TAP1 = 0xA0000003
    TAP2 = 0xC0000005

    def __init__(self, seed: int):
        s = seed & ((1 << SEED_BITS) - 1) or 1
        self.s1 = s & 0xFFFFFFFF
        self.s2 = (s * 0x9E3779B1) & 0xFFFFFFFF or 1

    @staticmethod
    def _step(state: int, tap: int) -> tuple[int, int]:
        lsb = state & 1
        state >>= 1
        if lsb:
            state ^= tap
        return state & 0xFFFFFFFF, lsb

    def next_bit(self) -> int:
        self.s1, b1 = self._step(self.s1, self.TAP1)
        self.s2, b2 = self._step(self.s2, self.TAP2)
        return b1 | b2

    def next_byte(self) -> int:
        v = 0
        for i in range(8):
            v |= self.next_bit() << i
        return v

    def keystream(self, n: int) -> bytes:
        return bytes(self.next_byte() for _ in range(n))


def gen_twin_primes():
    """p1, p2=p1+delta both prime; q1, q2 independent — gcd(n1,n2)=1."""
    while True:
        p1 = getPrime(P_BITS)
        delta = random.getrandbits(DELTA_BITS - 1) | (1 << (DELTA_BITS - 2))
        p2 = p1 + delta
        if p2.bit_length() != P_BITS or not isPrime(p2):
            continue
        q1 = getPrime(P_BITS)
        q2 = getPrime(P_BITS)
        if len({p1, p2, q1, q2}) < 4:
            continue
        n1, n2 = p1 * q1, p2 * q2
        if math.gcd(n1, n2) != 1:
            continue
        return p1, p2, q1, q2, delta, n1, n2


def main():
    p1, p2, q1, q2, delta, n1, n2 = gen_twin_primes()
    e = 0x10001
    assert math.gcd(n1, n2) == 1

    unknown = P_BITS - KNOWN_P_BITS
    p_high = p1 >> unknown
    ph_bytes = long_to_bytes(p_high, (KNOWN_P_BITS + 7) // 8)

    seed = random.getrandbits(SEED_BITS) or 1
    mask = CombGenerator(seed).keystream(len(ph_bytes))
    p_high_masked = xor_bytes(ph_bytes, mask)

    chal_pt = b"IVI-TBOX-SYNC-OK"
    chal_ct = xor_bytes(chal_pt, CombGenerator(seed).keystream(len(chal_pt)))

    secret = long_to_bytes(p1, P_BITS // 8) + long_to_bytes(q1, P_BITS // 8)
    flag = "flag{" + md5_hex(secret)[:16] + "}"

    header = f"OTA|{VIN}|".encode()
    body = header + flag.encode()
    pad_len = 96 - len(body)
    m = bytes_to_long(body + b"\x00" * pad_len)
    c_rsa = pow(m, e, n1)

    wrap_key = sha256(b"ifp-seal-v3" + secret)
    nonce = sha256(b"ifp-nonce-v3" + secret)[:16]
    stream = b""
    ctr = 0
    while len(stream) < len(flag):
        stream += sha256(wrap_key + nonce + ctr.to_bytes(4, "big"))
        ctr += 1
    ciphertext = xor_bytes(flag.encode(), stream[: len(flag)])

    # Publish delta in the clear as a distraction toward the old shared-q attack;
    # with independent q it does not yield a one-line factor.
    out = {
        "VIN": VIN,
        "n1": hex(n1),
        "n2": hex(n2),
        "e": hex(e),
        "c_rsa": hex(c_rsa),
        "p_bits": P_BITS,
        "known_p_msbs": KNOWN_P_BITS,
        "seed_bits": SEED_BITS,
        "p_high_masked_hex": p_high_masked.hex(),
        "challenge_ct_hex": chal_ct.hex(),
        "challenge_plain_hint": chal_pt.decode(),
        "comb_tap1": hex(CombGenerator.TAP1),
        "comb_tap2": hex(CombGenerator.TAP2),
        "enc_nonce_hex": nonce.hex(),
        "ciphertext_hex": ciphertext.hex(),
        # Explicit red herring for shared-q solvers:
        "delta_hint": hex(delta),
        "note": (
            "dual-ECU OTA moduli; diagnostics leak a masked MSB limb of the "
            "TBOX CRT prime. IVI modulus is a nearby-prime twin."
        ),
    }

    path = HERE / "output.txt"
    with open(path, "w") as f:
        json.dump(out, f, indent=2)

    print("[+] wrote", path)
    print("[+] flag", flag)
    print("[+] gcd(n1,n2)", math.gcd(n1, n2))
    print("[+] seed", hex(seed))
    print("[+] p_high", hex(p_high))
    print("[+] unknown bits", unknown)


if __name__ == "__main__":
    main()
