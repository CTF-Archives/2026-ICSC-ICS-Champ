#!/usr/bin/env sage
"""
V2X platoon BSM auth — offline challenge generator.
(Recover platoon signing material; open the sealed flag.)
"""

import hashlib
import json
import os
from random import SystemRandom

rand = SystemRandom()

# secp256r1
p = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
a_curve = p - 3
b_curve = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
n = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
Gx = 0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296
Gy = 0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5

E = EllipticCurve(GF(p), [a_curve, b_curve])
G = E(Gx, Gy)

# Unknown low bits of k. High part derived from BSM fields (see gen_k).
L = 108
NUM_SIGS = 99
# Fraction of signatures where HSM fell back to full-entropy k (must be filtered).
POISON_RATE = 0.05
FIXED_SEED = 0xC0FFEE2026B501

os.environ["PYTHONHASHSEED"] = "0"
set_random_seed(FIXED_SEED)
rand.seed(FIXED_SEED)


def i2b(x, length=32):
    return int(x).to_bytes(length, "big")


def b2i(b):
    return int.from_bytes(b, "big")


def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def md5(data: bytes) -> bytes:
    return hashlib.md5(data).digest()


def stream_crypt(key: bytes, iv: bytes, data: bytes) -> bytes:
    out = bytearray()
    ctr = 0
    while len(out) < len(data):
        out.extend(sha256(key + iv + ctr.to_bytes(4, "big")))
        ctr += 1
    return bytes(x ^^ y for x, y in zip(data, out))


def public_nonce_material(gps_time: int, counter: int, veh: int) -> int:
    """
    Material bound into k's high bits.
    Mixes timing fields with vehicle index (HSM firmware quirk).
    """
    digest = sha256(
        b"\x01\x60\x9e\x02"  # IEEE 1609.2-ish context tag
        + gps_time.to_bytes(8, "big")
        + counter.to_bytes(4, "big")
        + bytes([veh & 0xFF])
    )
    # Take top (256-L) bits, then XOR a veh-dependent limb so naive
    # "ignore veh" reconstructions are wrong.
    high = b2i(digest) >> L
    high = high ^^ ((veh * 0x9E3779B1) & ((1 << (256 - L)) - 1))
    return high


def gen_k(gps_time: int, counter: int, veh: int, poisoned: bool) -> int:
    if poisoned:
        while True:
            k = rand.randrange(1, n)
            if k:
                return int(k)
    high = public_nonce_material(gps_time, counter, veh)
    for _ in range(128):
        low = rand.getrandbits(L)
        k = (high << L) | low
        if 0 < k < n:
            return int(k)
    return int(((high << L) | rand.getrandbits(L)) % n) or 1


def ecdsa_sign(d, msg: bytes, gps_time: int, counter: int, veh: int, poisoned: bool):
    h = b2i(sha256(msg)) % n
    while True:
        k = gen_k(gps_time, counter, veh, poisoned)
        R = k * G
        r = int(R.xy()[0]) % n
        if r == 0:
            continue
        s = (inverse_mod(k, n) * (h + r * d)) % n
        if s == 0:
            continue
        return int(r), int(s)


# Platoon polynomial keying: d_i = d0 + i*alpha + i^2*beta  (mod n)
d0 = rand.randrange(1, n)
alpha = rand.randrange(1, n)
beta = rand.randrange(1, n)
privs = [int((d0 + i * alpha + (i * i) * beta) % n) for i in range(3)]
pubs = []
for d in privs:
    Q = d * G
    pubs.append({"x": hex(int(Q.xy()[0])), "y": hex(int(Q.xy()[1]))})

base_gps = 1_725_000_000
sigs = []
poison_flags = []  # author-only; NOT written to output
for j in range(NUM_SIGS):
    veh = j % 3
    gps_time = base_gps + (j * 7) % 50000
    counter = 0xA000 + j
    poisoned = rand.random() < POISON_RATE
    poison_flags.append(poisoned)
    msg = (
        b"BSM|"
        + f"id={veh}|t={gps_time}|c={counter}|spd={20 + (j % 15)}|hdg={(j * 11) % 360}".encode()
    )
    r, s = ecdsa_sign(privs[veh], msg, gps_time, counter, veh, poisoned)
    # Deliberately omit precomputed h — solvers must hash msg themselves.
    # Deliberately omit L / poison info.
    sigs.append(
        {
            "veh": int(veh),
            "gps_time": int(gps_time),
            "counter": int(counter),
            "msg_hex": msg.hex(),
            "r": hex(r),
            "s": hex(s),
        }
    )

# Nested seal: flag depends on all three secrets; ciphertext key mixes them
# with an extra "platoon epoch" derived from the quadratic evaluation at i=3
# (not a deployed vehicle — only appears in KDF).
d3 = int((d0 + 3 * alpha + 9 * beta) % n)
secret = i2b(d0) + i2b(alpha) + i2b(beta) + i2b(d3)
flag = "flag{" + md5(secret).hex()[:16] + "}"
aes_key = sha256(b"platoon-seal-v2" + secret)
enc_nonce = sha256(b"nonce" + secret)[:16]
ciphertext = stream_crypt(aes_key, enc_nonce, flag.encode())

# Red herring blob (looks like a fourth pubkey / unused cert)
rh = sha256(b"redherring" + i2b(rand.randrange(1, n)))
red_herring = {
    "cert_serial": rh[:8].hex(),
    "spurious_x": hex(b2i(rh)),
    "comment": "SCMS linkage leftover — not required",
}

out = {
    "curve": "secp256r1",
    "n": hex(int(n)),
    "G": {"x": hex(int(Gx)), "y": hex(int(Gy))},
    "vehicles": pubs,
    "enc_nonce_hex": enc_nonce.hex(),
    "ciphertext_hex": ciphertext.hex(),
    "signatures": sigs,
    "meta": red_herring,
}

path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output.txt")
with open(path, "w") as f:
    json.dump(out, f, indent=2)

print("[+] wrote", path)
print("[+] flag", flag)
print("[+] L", L, "poisoned", sum(1 for x in poison_flags if x), "/", NUM_SIGS)
print("[+] d0", hex(d0))
print("[+] alpha", hex(alpha))
print("[+] beta", hex(beta))
print("[+] d3", hex(d3))
